# CS4NLP-Project
Repository for the course project of CSNLP'24.

The api keys for openai models go in an `openai.key` file in the root folder.
