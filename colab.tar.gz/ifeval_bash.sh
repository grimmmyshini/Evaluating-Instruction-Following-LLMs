python3 -m instruction_following_eval.evaluation_main \
  --input_data=datasets/InfoToIfeval/infoToIfeval.jsonl \
  --input_response_data=datasets/InfoToIfeval/response/infoToIfeval/gpt4o/output.jsonl \
  --output_dir=datasets/InfoToIfeval/response/infoToIfeval/gpt4o